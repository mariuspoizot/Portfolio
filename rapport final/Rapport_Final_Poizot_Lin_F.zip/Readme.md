## Comment convertir Markdown en PDF et HTML 

## Première solution (celle utilisé dans notre cas)

1. Dans l'editeur VScode , allez dans la rubrique "extensions" et taper Mardown . 
2. Choisir l'extensions nommé "Markdown PDF " 
3. Cliquez sur "Installer" 
4. Une fois installé et votre fichier Markdown fini cliquez sur la barre de recherche et taper : >export (en étant sur le fichier voulant être exporté) 
5. VScode vous proposera différents formats dans lequel le fichier peut être exporté notamment en PDF et HTML (grâce à l'extension) .
6. Choisir PDF 

## Deuxieme Solution 
1. Allez dans un éditeur en ligne pour Markdown (Stackedit.io par exemple ) 
2. Une fois votre fichier Markdown écrit cliquez sur le logo(avec un #)  en haut a droite 
3. Cliquez sur import/export 
4. Cliquez sur "export as HTML "
5. Vous ne pouvez en revanche pas l'exporter en PDF  a moins d'avoir la version payante . 
