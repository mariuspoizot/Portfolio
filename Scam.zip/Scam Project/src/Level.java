class Level {
    boolean[][] placeableZone;
    Cube[][] tab;
    boolean[][] motif;
    int moves;
    int placements;
}
