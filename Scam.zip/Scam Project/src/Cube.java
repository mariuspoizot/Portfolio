class Cube {
	int type = 0;
	Direction direction;
	char symbol;
	boolean moved = false;
}
