enum Direction {NONE,RIGHT,DOWN,LEFT,UP}
